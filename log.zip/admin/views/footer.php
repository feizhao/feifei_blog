<?php if(!defined('__ROOT__')) {exit('error!');}?>
	</div><!--end container-->
	<div id="footer">powered by <a href="http://zhaofei.sinaapp.com/">后天的网络笔记</a></div>
</div><!--end mainpage-->
</body>
</html>