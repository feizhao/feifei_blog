<?php if(!defined('__ROOT__')) {exit('error!');}?>
	</div><!--end container-->
	<div id="footer">欢迎使用 &copy; <a href="http://www.emlog.net" target="_blank">emlog</a><?php doAction('adm_footer');?></div>
</div><!--end mainpage-->
</body>
</html>