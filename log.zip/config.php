<?php
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','root');
//database password
define('DB_PASSWD','zhaofei');
//database name
define('DB_NAME','blog');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','VyZjBTtBd%O5GlFBbMo3gs3)6tTNNin*dbe228e36cad75be403270fab5fb837a');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_qurqIzbGdmyjv254YGBuE1fdqua2DpZ3');
