<?php
//sae
// define('IS_SAE', true);
// //mysql database address
// define('DB_HOST',SAE_MYSQL_HOST_M);
// //mysql database user
// define('DB_USER',SAE_MYSQL_USER);
// //database password
// define('DB_PASSWD',SAE_MYSQL_PASS);
// //database name
// define('DB_NAME',SAE_MYSQL_DB);
// //dadatabase port
// define('DB_PORT',SAE_MYSQL_PORT);
// //database prefix
// define('DB_PREFIX','emlog_');

define('IS_SAE', false);
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','root');
//database password
define('DB_PASSWD','zhaofei');
//database name
define('DB_NAME','blog');
//dadatabase port
define('DB_PORT','3306');
//database prefix
define('DB_PREFIX','emlog_');

//auth key
define('AUTH_KEY','VyZjBTtBd%O5GlFBbMo3gs3)6tTNNin*dbe228e36cad75be403270fab5fb837a');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_qurqIzbGdmyjv254YGBuE1fdqua2DpZ3');

